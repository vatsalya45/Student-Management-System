package com.vatsalya.view_all_students.copy;

public class ViewAllStudentsDAO {

}
