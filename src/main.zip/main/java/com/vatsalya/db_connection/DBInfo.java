package com.vatsalya.db_connection;

public interface DBInfo {
	
	public static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String DB_URL= "jdbc:oracle:thin:@localhost:1521:orcl";
	public static final String DB_USER_NAME = "vatsalya";
	public static final String DB_PASSWORD = "vasu";
		

}
